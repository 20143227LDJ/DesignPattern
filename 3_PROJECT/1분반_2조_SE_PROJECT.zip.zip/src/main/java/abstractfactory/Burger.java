package abstractfactory;

public interface Burger {
    
  @Override
  String toString();
}
