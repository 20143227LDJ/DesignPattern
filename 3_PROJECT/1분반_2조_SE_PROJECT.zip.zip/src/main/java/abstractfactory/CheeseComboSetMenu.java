package abstractfactory;

public class CheeseComboSetMenu extends ComboSetMenu {
    private ComboSetFactory setFactory;
    
  public  CheeseComboSetMenu() {
      this.setFactory=new CheeseComboSetFactory();
  }

    @Override
  protected ComboSet createComboSet(String type) {
      ComboSet comboset = null;
      
      if(type.equals("Nacho")){
          comboset = new NachoComboSet(setFactory);
          comboset.setName("치즈나쵸콤보 세트메뉴");
      }else if(type.equals("Burger")){
          comboset = new BurgerComboSet(setFactory);
          comboset.setName("치즈버거콤보 세트메뉴");
      }
    return comboset;
  }
}
