package abstractfactory;

public class CheeseComboSetFactory implements ComboSetFactory {
  public Popcorn createPopcorn() {
      return new CheesePopcorn();
  }

  public Drink createDrink() {
      return new Cola();
  }

  public HotDog createHotdog() {
      return new CheeseHotdog();
  }

  public Nacho createNacho() {
      return new CheeseNacho();
  }

  public Burger createBurger() {
      return new CheeseBurger();
  }
  
}
