package abstractfactory;

public class BurgerComboSet extends ComboSet {
    
  private ComboSetFactory setFactory;
  
  public BurgerComboSet(ComboSetFactory setFactory) {
      this.setFactory=setFactory;
  }

  @Override
  public void prepare() {
      popcorn = setFactory.createPopcorn();
      drink = setFactory.createDrink();
      burger = setFactory.createBurger();
  }
}
