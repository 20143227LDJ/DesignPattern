package abstractfactory;

public class Cola implements Drink {
    
     @Override
    public String toString(){
        return "콜라";
    }
}
