package abstractfactory;

public abstract class ComboSetMenu {
    
  protected abstract ComboSet createComboSet(String type);
  
  public ComboSet orderComboSet(String type) {
      ComboSet comboset = createComboSet(type);
      comboset.prepare();
      return comboset;
  }
}
