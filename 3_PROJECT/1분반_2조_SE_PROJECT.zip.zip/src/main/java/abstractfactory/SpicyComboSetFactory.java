package abstractfactory;

public class SpicyComboSetFactory implements ComboSetFactory {
  @Override
  public Popcorn createPopcorn() {
      return new SpicyPopcorn();
  }

  @Override
  public Drink createDrink() {
      return new Cider();
  }

  @Override
  public HotDog createHotdog(){
      return new SpicyHotdog();
  }

  @Override
  public Nacho createNacho() {
      return new SpicyNacho();
  }

  @Override
  public Burger createBurger() {
      return new SpicyBurger();
  }
}
