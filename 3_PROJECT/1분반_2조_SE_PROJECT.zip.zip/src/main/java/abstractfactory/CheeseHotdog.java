package abstractfactory;

public class CheeseHotdog implements HotDog {
    
     @Override
    public String toString(){
        return "치즈핫도그";
    }
}
