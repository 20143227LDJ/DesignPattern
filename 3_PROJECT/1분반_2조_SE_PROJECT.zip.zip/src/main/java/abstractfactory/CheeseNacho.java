package abstractfactory;

public class CheeseNacho implements Nacho {
    
     @Override
    public String toString(){
        return "치즈나쵸";
    }
}
