package abstractfactory;

public class Cider implements Drink {
    
     @Override
    public String toString(){
        return "사이다";
    }
}
