package abstractfactory;

public class CaramelPopcorn implements Popcorn {
    
    @Override
    public String toString(){
        return"카라멜 팝콘";
    }
}
