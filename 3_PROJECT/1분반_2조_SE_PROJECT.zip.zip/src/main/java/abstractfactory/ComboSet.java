package abstractfactory;

public abstract class ComboSet {
  protected String name;
  protected Popcorn popcorn;
  protected Drink drink;
  protected HotDog hotdog;
  protected Burger burger;
  protected Nacho nacho;

  public void prepare() {
  }

  public void setName(String name) {
      this.name=name;
  }

  public String getName() {
      return name;
  }

  public String toString() {
    
      StringBuilder result =  new StringBuilder();
      result.append("").append(name).append("(");
      if(popcorn !=null){
          result.append(popcorn);
      }
      if(drink !=null){
          result.append(", ");
      }
      if(drink !=null){
          result.append(drink);
      }
      if(hotdog !=null){
          result.append(", ");
      }
      if(hotdog !=null){
          result.append(hotdog);
      }
      if(burger !=null){
          result.append(", ");
      }
      if(burger !=null){
          result.append(burger);
      }
      if(nacho !=null){
          result.append(", ");
      }
      if(nacho !=null){
          result.append(nacho);
      }
      result.append(")");
      return result.toString();
      
  }
}