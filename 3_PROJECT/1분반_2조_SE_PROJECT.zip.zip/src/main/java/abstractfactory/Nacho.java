package abstractfactory;

public interface Nacho {
    
  @Override
  String toString();
}
