package abstractfactory;

public interface Popcorn {
    
  @Override
  String toString();
}
