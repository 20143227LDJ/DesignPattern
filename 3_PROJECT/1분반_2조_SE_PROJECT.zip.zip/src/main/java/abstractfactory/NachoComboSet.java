package abstractfactory;

public class NachoComboSet extends ComboSet {
   
  private ComboSetFactory setFactory;

  public NachoComboSet(ComboSetFactory setFactory) {
      this.setFactory=setFactory;
  }

  @Override
  public void prepare() {
      popcorn = setFactory.createPopcorn();
      drink = setFactory.createDrink();
      nacho = setFactory.createNacho();
  }
}
