package abstractfactory;

public class CheesePopcorn implements Popcorn {
    
    @Override
    public String toString(){
        return "치즈팝콘";
    }
}
