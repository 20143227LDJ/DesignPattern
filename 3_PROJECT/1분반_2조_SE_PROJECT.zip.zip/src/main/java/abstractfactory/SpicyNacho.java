package abstractfactory;

public class SpicyNacho implements Nacho {
    
     @Override
    public String toString(){
        return "매콤나쵸";
    }
}
