package abstractfactory;

public class SpicyComboSetMenu extends ComboSetMenu { 
    
    private ComboSetFactory setFactory ;
    
  public SpicyComboSetMenu(){
      this.setFactory= new SpicyComboSetFactory();
  }
  
  protected ComboSet createComboSet(String type) {
           ComboSet comboset = null;
      
      if(type.equals("Nacho")){
          comboset = new NachoComboSet(setFactory);
          comboset.setName("매콤나쵸콤보 세트메뉴");
      }else if(type.equals("Burger")){
          comboset = new BurgerComboSet(setFactory);
          comboset.setName("매콤햄버거콤보 세트메뉴");
      }
    return comboset;
  }
}
