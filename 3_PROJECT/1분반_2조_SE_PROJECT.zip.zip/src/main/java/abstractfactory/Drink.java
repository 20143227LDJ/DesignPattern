package abstractfactory;


public interface Drink {
  @Override
  String toString();

}
