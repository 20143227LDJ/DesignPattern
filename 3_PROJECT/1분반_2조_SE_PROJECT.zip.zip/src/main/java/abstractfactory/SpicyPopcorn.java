package abstractfactory;

public class SpicyPopcorn implements Popcorn {
    
     @Override
    public String toString(){
        return "매콤팝콘";
    }
}
