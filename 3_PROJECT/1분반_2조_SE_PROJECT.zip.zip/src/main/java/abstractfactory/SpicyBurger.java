package abstractfactory;

public class SpicyBurger implements Burger {
    
     @Override
    public String toString(){
        return "매콤햄버거";
    }
}
