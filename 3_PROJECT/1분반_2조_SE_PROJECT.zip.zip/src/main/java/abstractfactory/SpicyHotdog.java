package abstractfactory;

public class SpicyHotdog implements HotDog {
    
     @Override
    public String toString(){
        return "매콤핫도그";
    }
}
