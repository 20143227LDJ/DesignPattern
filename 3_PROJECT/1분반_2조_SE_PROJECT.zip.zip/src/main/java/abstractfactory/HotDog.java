package abstractfactory;

public interface HotDog {
    
  @Override
  String toString();
}
