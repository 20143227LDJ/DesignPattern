package abstractfactory;

public interface ComboSetFactory {
  Popcorn createPopcorn() ;

  Drink createDrink() ;

  HotDog createHotdog() ;

  Burger createBurger() ;

  Nacho createNacho() ;

}
