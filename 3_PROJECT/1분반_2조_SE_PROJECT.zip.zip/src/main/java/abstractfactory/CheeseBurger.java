package abstractfactory;

public class CheeseBurger implements Burger {
    
     @Override
    public String toString(){
        return "치즈햄버거";
    }
}
