package command;

public class BurgerChef {
    
  public void makeBurger(String burgerMenu) {
      System.out.println("주방에서 "+burgerMenu+"를 만듭니다.");
  }

}
