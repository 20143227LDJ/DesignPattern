package command;

public class NachoChef {
    
  public void makeNacho(String nachoMenu) {
      System.out.println("주방에서 "+nachoMenu+"를 만듭니다.");
  }
 
}
