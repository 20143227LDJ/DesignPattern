package command;

public class PopcornChef {
    
  public void makePopcorn(String popcornMenu) {
      
      System.out.println("주방에서 "+popcornMenu+"를 만듭니다.");
  }
}
