package command;

public class SetChef {
    
  public void makeSet(String setMenu) {
      System.out.println("주방에서 "+setMenu+"를 만듭니다.");
  }
 
}
