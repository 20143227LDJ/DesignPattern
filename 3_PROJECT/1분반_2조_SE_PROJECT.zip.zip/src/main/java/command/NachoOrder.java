package command;

import abstractfactory.CheeseNacho;
import abstractfactory.Nacho;
import abstractfactory.SpicyNacho;
import java.util.Scanner;

public class NachoOrder implements Command {
    Nacho cn = new CheeseNacho();
    Nacho sn = new SpicyNacho();
    
    private NachoChef nachoChef;
    String[] nachoMenu = {"주문완료", "주문목록 초기화",cn.toString(),sn.toString()};//메뉴 이름
    int[] nachoPrice = { 0, 0, 3000, 2500};//메뉴 가격
    int[] nachoNum ={0, 1, 2, 3};// 메뉴 번호
    String orderList=("");// 주문 목록
    int totalPrice=0;//총액
    int[] nachoCount={0,0};//개수
    int min=0;

    public NachoOrder(NachoChef nachoChef){
        this.nachoChef = nachoChef;
    }
   
    @Override
     public void orderUp() {
      String spacing="";// 띄워쓰기
      Scanner scan =new Scanner(System.in);
      int a = 0;
      
      System.out.println("주문하고 싶은 메뉴 번호를 선택하여 입력해 주세요."
              + "\n나쵸메뉴 목록\n-----------------------------");
        
      for(int i=0; i<nachoMenu.length;i++){
          if(nachoMenu[i].length()==4) spacing="           ";
          else if(nachoMenu[i].length()==6) spacing="       ";
          
          if (i<2) System.out.println(nachoNum[i]+"   "+nachoMenu[i]);
          else System.out.print(nachoNum[i]+"   "+nachoMenu[i]+spacing+nachoPrice[i]+"원\n");
      }
      System.out.println("-----------------------------");
      while(true){
          
          a = scan.nextInt();
         
          if(a==0){// 주문 완료를 입력시
              for(int i=0;i<2;i++){
                      if(nachoCount[i]!=0){
                          if(orderList.equals(""))orderList=nachoMenu[i+2]+" "+nachoCount[i]+"개";
                          else orderList=orderList+","+nachoMenu[i+2]+" "+nachoCount[i]+"개";
                      }
                  }
              if(orderList.equals("")) System.out.println("주문 목록이 없습니다.");
              //아무것도 넣지 않았을 때
              else{
                  System.out.println("주문이 완료 되었습니다.\n");
                  break;
             }
          }
          else if(a==1){//주문 목록 초기화
              for(int i=0;i<2;i++) nachoCount[i]=0;
              orderList=("");
              totalPrice=0;
              System.out.println("주문목록을 초기화 시켰습니다.");
              min=0;
              
          }
          else if(a>1 && a<4) {//메뉴 주문목록에 담기
             
              nachoCount[a-2]++;
              System.out.println(nachoMenu[a]+"를(을) 주문 목록에 넣었습니다.");
              totalPrice=totalPrice+nachoPrice[a];
              min++;
          }
          else System.out.println("잘못된 번호를 입력하셨습니다.");
        
      }
         
         System.out.println("주문목록:"+orderList+"\n총 금액:"+totalPrice+"원");
         System.out.println(min+"분 정도 기다려주세요...");
         nachoChef.makeNacho(orderList);
    }
 
}
