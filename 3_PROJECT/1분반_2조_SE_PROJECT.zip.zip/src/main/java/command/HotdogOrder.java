package command;

import abstractfactory.CheeseHotdog;
import abstractfactory.HotDog;
import abstractfactory.SpicyHotdog;
import java.util.Scanner;

public class HotdogOrder implements Command {
    HotDog ch = new CheeseHotdog();
    HotDog sh = new SpicyHotdog();
    
    private HotdogChef hotdogChef;
    String[] hotdogMenu = {"주문완료", "주문목록 초기화",ch.toString(),sh.toString()};//메뉴 이름
    int[] hotdogPrice = { 0, 0, 4000,3500};//메뉴 가격
    int[] hotdogNum ={0, 1, 2, 3};// 메뉴 번호
    String orderList=("");// 주문 목록
    int totalPrice=0;//총액
    int[] hotdogCount={0,0};//개수
    int min=0;

    public HotdogOrder(HotdogChef hotdogChef){
        this.hotdogChef = hotdogChef;
    }
   
    @Override
     public void orderUp() {
      String spacing="";// 띄워쓰기
      Scanner scan =new Scanner(System.in);
      int a = 0;
      
      System.out.println("주문하고 싶은 메뉴 번호를 선택하여 입력해 주세요."
              + "\n핫도그메뉴 목록\n---------------------------");
        
      for(int i=0; i<hotdogMenu.length;i++){
          if(hotdogMenu[i].length()==6) spacing="           ";
          else if(hotdogMenu[i].length()==8) spacing="       ";
          
          if (i<2) System.out.println(hotdogNum[i]+"   "+hotdogMenu[i]);
          else System.out.print(hotdogNum[i]+"   "+hotdogMenu[i]+spacing+hotdogPrice[i]+"원\n");
      }
      System.out.println("---------------------------");
      while(true){
          
          a = scan.nextInt();
         
          if(a==0){// 주문 완료를 입력시
              for(int i=0;i<2;i++){
                      if(hotdogCount[i]!=0){
                          if(orderList.equals(""))orderList=hotdogMenu[i+2]+" "+hotdogCount[i]+"개";
                          else orderList=orderList+","+hotdogMenu[i+2]+" "+hotdogCount[i]+"개";
                      }
                  }
              if(orderList.equals("")) System.out.println("주문 목록이 없습니다.");
              //아무것도 넣지 않았을 때
              else{
                  System.out.println("주문이 완료 되었습니다.\n");
                  break;
             }
          }
          else if(a==1){//주문 목록 초기화
              for(int i=0;i<2;i++) hotdogCount[i]=0;
              orderList=("");
              totalPrice=0;
              System.out.println("주문목록을 초기화 시켰습니다.");
              min=0;
          }
          else if(a>1 && a<4) {//메뉴 주문목록에 담기
             
              hotdogCount[a-2]++;
              System.out.println(hotdogMenu[a]+"를(을) 주문 목록에 넣었습니다.");
              totalPrice=totalPrice+hotdogPrice[a];
              min=min+4;
          }
          else System.out.println("잘못된 번호를 입력하셨습니다.");
        
      }
         
         System.out.println("주문목록:"+orderList+"\n총 금액:"+totalPrice+"원");
         System.out.println(min+"분 정도 기다려주세요...");
         hotdogChef.makeHotdog(orderList);
    }
 
}
