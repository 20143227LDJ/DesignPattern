package command;

public class Staff {
    private Command command;
      
    public void takeOrder() {
      command.orderUp();
    }
    
    public void setCommand(Command command) {
        this.command = command;
    }
    
    public Staff(Command command){
        setCommand(command);
    }
}   
    

