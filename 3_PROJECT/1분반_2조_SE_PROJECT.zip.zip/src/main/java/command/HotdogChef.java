package command;

public class HotdogChef {
    
  public void makeHotdog(String hotdogMenu) {
      System.out.println("주방에서 "+hotdogMenu+"를 만듭니다.");
  }
 
}
