package command;

import abstractfactory.CheeseComboSetMenu;
import abstractfactory.ComboSet;
import abstractfactory.ComboSetMenu;
import abstractfactory.SpicyComboSetMenu;
import java.util.Scanner;

public class SetOrder implements Command {
    private SetChef setChef;
    String[] setMenu = {"주문완료", "주문목록 초기화","","","",""};//메뉴 이름
    int[] setPrice = { 0, 0, 9000, 10000, 11000, 12000};//메뉴 가격
    int[] setNum ={0, 1, 2, 3, 4, 5};// 메뉴 번호
    String orderList=("");// 주문 목록
    int totalPrice=0;//총액
    int[] setCount={0,0,0,0};//개수
    int sec=0;
    int min=0;
    
    ComboSetMenu SpicyMenu = new SpicyComboSetMenu();
    ComboSetMenu CheeseMenu = new CheeseComboSetMenu();

    public SetOrder(SetChef setChef){
        this.setChef = setChef;
    }
   
    @Override
     public void orderUp() {
         
        ComboSet comboset = SpicyMenu.orderComboSet("Nacho");
        setMenu[2]=comboset.toString();

        comboset = CheeseMenu.orderComboSet("Nacho");
        setMenu[3]=comboset.toString();
        
        comboset = SpicyMenu.orderComboSet("Burger");
        setMenu[4]=comboset.toString();
        
        comboset = CheeseMenu.orderComboSet("Burger");
        setMenu[5]=comboset.toString();
      
      String spacing="";// 띄워쓰기
      Scanner scan =new Scanner(System.in);
      int a = 0;
      
      System.out.println("주문하고 싶은 메뉴 번호를 선택하여 입력해 주세요."
              + "\n세트메뉴 목록\n--------------------------------"
              + "-------------------------------");
        
      for(int i=0; i<setMenu.length;i++){
          if(setMenu[i].length()==27) spacing="        ";
          else if(setMenu[i].length()==28) spacing="      ";
          else if(setMenu[i].length()==30) spacing ="  ";
          
          if (i<2) System.out.println(setNum[i]+"   "+setMenu[i]);
          else System.out.print(setNum[i]+"   "+setMenu[i]+spacing+setPrice[i]+"원\n");
      }
      System.out.println("------------------------------------"
              + "---------------------------");
      while(true){
          
          a = scan.nextInt();
         
          if(a==0){// 주문 완료를 입력시
              for(int i=0;i<4;i++){
                      if(setCount[i]!=0){
                          if(orderList.equals(""))orderList=setMenu[i+2]+" "+setCount[i]+"개";
                          else orderList=orderList+","+setMenu[i+2]+" "+setCount[i]+"개";
                      }
                  }
              if(orderList.equals("")) System.out.println("주문 목록이 없습니다.");
              //아무것도 넣지 않았을 때
              else{
                  System.out.println("주문이 완료 되었습니다.\n");
                  break;
             }
          }
          else if(a==1){//주문 목록 초기화
              for(int i=0;i<4;i++) setCount[i]=0;
              orderList=("");
              totalPrice=0;
              System.out.println("주문목록을 초기화 시켰습니다.");
              sec=0;
          }
          else if(a>1 && a<6) {//메뉴 주문목록에 담기
              setCount[a-2]++;
              System.out.println(setMenu[a]+"를(을) 주문 목록에 넣었습니다.");
              totalPrice=totalPrice+setPrice[a];
              if(a<4)sec=sec+170;
              else sec=sec+410;
          }
          else System.out.println("잘못된 번호를 입력하셨습니다.");
        
      }
         
         System.out.println("주문목록:"+orderList+"\n총 금액:"+totalPrice+"원");
         min=sec/60;
         sec=sec%60;
         System.out.println(min+"분"+sec+"초 정도 기다려주세요...");
         setChef.makeSet(orderList);
    }
}
