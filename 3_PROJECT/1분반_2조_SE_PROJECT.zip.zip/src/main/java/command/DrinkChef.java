package command;

public class DrinkChef {
    
  public void makeDrink(String drinkMenu) {
      
      System.out.println("주방에서 "+drinkMenu+"를 만듭니다.");
  }
}
