
package observer;

import java.util.LinkedList;

public class ParkingInformation extends Subject {
  private int totalSeat;
  private int useSeat;

  public ParkingInformation() {
      mObserver = new LinkedList<>();
  }

  @Override
  public void registerObserver(Observer o) {
      mObserver.add(o);
  }

  @Override
  public void removeObserver(Observer o) {
      int i = mObserver.indexOf(o);
      if(i>=0){
          mObserver.remove(i);
      }
  }

  @Override
  public void notifyObservers() {
      mObserver.forEach( observer ->
          observer.update(totalSeat, useSeat)
      );
  }
  
  public void informationChanged() {
      notifyObservers();
  }

  public void setInformation(int totalSeat, int useSeat) {
      this.totalSeat = totalSeat;
      this.useSeat = useSeat;
      
      informationChanged();
  }

}
