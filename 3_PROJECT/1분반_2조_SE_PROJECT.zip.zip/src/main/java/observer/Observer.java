
package observer;

interface Observer {
  void update(int totalSeat, int useSeat) ;
  void add(ParkingInformation parkingInformation);
  void remove();

}
