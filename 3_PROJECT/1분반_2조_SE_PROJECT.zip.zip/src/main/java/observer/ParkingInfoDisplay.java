
package observer;

public class ParkingInfoDisplay implements Observer, DisplayElement {
  private int totalSeat;
  private int useSeat;
  private ParkingInformation parkingInformation;
  
  public ParkingInfoDisplay(ParkingInformation parkingInformation) {
      this.parkingInformation = parkingInformation;
      this.parkingInformation.registerObserver(this);
  }

  @Override
  public void update(int totalSeat, int useSeat) {
      this.totalSeat = totalSeat;
      this.useSeat = useSeat;
      display();
  }
  
  @Override
  public void add(ParkingInformation parkingInformation){
      this.parkingInformation.registerObserver(this);
  }
  
  @Override
  public void remove(){
      this.parkingInformation.removeObserver(this);
  }

  @Override
  public void display() {
      System.out.println("총 " + totalSeat + "대 주차 가능");
      System.out.println(useSeat + "대 주차 중");
  }
  
}
