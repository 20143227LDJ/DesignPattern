
package observer;

public class SeatCheckDisplay implements Observer, DisplayElement {
  private int emptySeat;
  private String seatCheck;
  private ParkingInformation parkingInformation;

  public SeatCheckDisplay(ParkingInformation parkingInformation) {
      this.parkingInformation = parkingInformation;
      this.parkingInformation.registerObserver(this);
  }

  @Override
  public void update(int totalSeat, int useSeat) {
      emptySeat = totalSeat - useSeat;
      
      if((float)emptySeat/totalSeat >= 0.8){
          seatCheck = "원활";
      }else if((float)emptySeat/totalSeat >= 0.5){
          seatCheck = "보통";
      }else{
          seatCheck = "혼잡";
      }
      
      display();
  }
  
  @Override
  public void add(ParkingInformation parkingInformation){
      this.parkingInformation.registerObserver(this);
  }
  
  @Override
  public void remove(){
      this.parkingInformation.removeObserver(this);
  }

  @Override
  public void display() {
      System.out.println("현재 " + emptySeat + "대 주차가능");
      System.out.println("주차장 혼잡도 : " + seatCheck);
  }

}
