
package observer;

import java.util.List;

abstract class Subject {
  protected List<Observer> mObserver;
  
  public abstract void registerObserver(Observer o) ;
  public abstract void removeObserver(Observer o) ;
  public abstract void notifyObservers() ;

}
