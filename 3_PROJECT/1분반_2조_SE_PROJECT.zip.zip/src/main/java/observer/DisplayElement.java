
package observer;

interface DisplayElement {
  void display() ;

}
