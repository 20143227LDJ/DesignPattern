
package client;

import builder.MovieInfomationBuilder;
import builder.MovieInformation;
import command.BurgerChef;
import command.BurgerOrder;
import command.DrinkChef;
import command.DrinkOrder;
import command.HotdogChef;
import command.HotdogOrder;
import command.NachoChef;
import command.NachoOrder;
import command.PopcornChef;
import command.PopcornOrder;
import command.SetChef;
import command.SetOrder;
import command.Staff;
import decorator.CardDiscount;
import decorator.EarlyMorningMoive;
import decorator.LateNightMoive;
import decorator.Moive;
import decorator.StudentDiscount;
import decorator.Ticket;
import iterator.MovieDisplay;
import iterator.MovieList;
import iterator.ReOpenMovieList;
import java.io.IOException;
import java.util.Scanner;
import observer.ParkingInfoDisplay;
import observer.ParkingInformation;
import observer.SeatCheckDisplay;
import selectinformation.DiscountSelect;
import selectinformation.MovieSelect;
import selectinformation.PersonNumberSelect;
import selectinformation.SeatSelect;
import selectinformation.TheaterSelect;
import selectinformation.TimeSelect;

public class MainDisplay {
    int seat = 47;
    
    public static void main(String[] args) throws InterruptedException, IOException {
        MainDisplay mainDisplay = new MainDisplay();
        Scanner scan = new Scanner(System.in);
        int choice = 0;
        
        while(true){
            Thread.sleep(1000);
            mainDisplay.deuCinema();
            choice = scan.nextInt();
            
            if(choice == 5){
                break;
            }else{
                switch(choice){
                case 1:
                    mainDisplay.MovieInformaiton();
                    break;
                case 2:
                    mainDisplay.TicketPrice();
                    break;
                case 3:
                    mainDisplay.SnackBar();
                    break;
                 case 4:
                    mainDisplay.ParkingInformation();
                    break;
                default:
                    System.out.println("잘못 입력하셨습니다.");
                    break;
                }
            }
            

        }
  
    }
    
    public void deuCinema(){
        System.out.println("--------메뉴 선택--------");
        System.out.println("1. 영화 정보 확인");
        System.out.println("2. 티켓 예매");
        System.out.println("3. 스낵바");
        System.out.println("4. 주차장 정보 확인");
        System.out.println("5. 종료");
        System.out.println("-------------------------");
    }
    
    public void TicketPrice(){
        MovieSelect movie = new MovieSelect();
        TheaterSelect theater = new TheaterSelect();
        TimeSelect time = new TimeSelect();
        DiscountSelect discount = new DiscountSelect();
        PersonNumberSelect p = new PersonNumberSelect();
        SeatSelect seat;
        Ticket t1;
        Scanner scan = new Scanner(System.in);
        String str;
        
        MovieInfomationBuilder movieinfomationbuilder = new MovieInfomationBuilder();
        // 빌더 객체에 원하는 데이터를 입력합니다. 순서는 상관 없습니다.
        MovieInformation result;
        
        theater.showTheaterInformation();
        movieinfomationbuilder.setTheater(theater.selectTheater());
        
        movie.showMovieInformation();
        movieinfomationbuilder.setName(movie.selectMovie());
        
        time.showTimeInformation();
        movieinfomationbuilder.setTime(time.selectTime());
        
        movieinfomationbuilder.setPersonNumber(p.selectPersonNumber());
        
        seat = new SeatSelect(p.getPnum());
        
        seat.showSeatInformation();
        movieinfomationbuilder.setSeat(seat.selectSeat());
        
        discount.showDiscountInformation();
        movieinfomationbuilder.setDiscount(discount.selectDiscount());
        
        result = movieinfomationbuilder.build();
        System.out.println(result.getMovieInfo());
    
        
        if(result.getTime() == 1){
            t1 = new EarlyMorningMoive();
        }
        else if(result.getTime() == 2){
            t1 = new Moive();
        }
        else{
            t1 = new LateNightMoive();
        }
        

        if(result.getDiscount() == 1){
            t1 = new StudentDiscount(t1);
        }
        else if(result.getDiscount() == 2){
            t1 = new CardDiscount(t1);
        }
        else if(result.getDiscount() == 3){
            t1 = new CardDiscount(t1);
            t1 = new StudentDiscount(t1);
        }
        else if(result.getDiscount() == 4){
            //할인 선택을 안해서 내용 없음
        }

        System.out.println("-----결제 예정 금액 안내-----");
        System.out.println(t1.getDescription()+" "+result.getPersonNumber()+ "명 " + result.getPersonNumber()*t1.price()+"원");
        System.out.println("----------------------------");
        
        while(true){
            System.out.println("결제를 진행하시겠습니까? y/n");
            str = scan.nextLine();
            
            if(str.equals("y")){
                System.out.println("결제를 진행합니다.");
                break;
            }
            else if(str.equals("n")){
                System.out.println("결제를 취소합니다.");
                break;
            }
        }
    }
    
    public void ParkingInformation(){
        ParkingInformation parkingInformation = new ParkingInformation();
        ParkingInfoDisplay parkingInfoDisplay = new ParkingInfoDisplay(parkingInformation);
        SeatCheckDisplay seatCheckDisplay = new SeatCheckDisplay(parkingInformation);
        Scanner scan = new Scanner(System.in);
        String input;
        int input2;
        
        
        System.out.println("차의 유무? (y/n)");
        input = scan.nextLine();
        
        if(input.equals("y")){
            seat++;
            
            while(true){
                System.out.println("----------------------------------");
                System.out.println("원하는 기능을 입력하세요");
                System.out.println("1: 주자장 공간 정보 보기");
                System.out.println("2: 현재 주차 가능한 공간 및 혼잡도 보기");
                System.out.println("3: 모두 보기");
                System.out.println("4: 종  료");
                System.out.println("----------------------------------");
                
                input2 = scan.nextInt();

                if(input2 == 1){
                    System.out.println("----------------------------------");
                    seatCheckDisplay.remove();
                    parkingInformation.setInformation(154, seat);
                    seatCheckDisplay.add(parkingInformation);
                }else if(input2 == 2){
                    System.out.println("----------------------------------");
                    parkingInfoDisplay.remove();
                    parkingInformation.setInformation(154, seat);
                    parkingInfoDisplay.add(parkingInformation);
                }else if(input2 == 3){
                    System.out.println("----------------------------------");
                    parkingInformation.setInformation(154, seat);
                }else if(input2 == 4){
                    break;
                }else{
                    System.out.println("잘못 입력하셨습니다.");
                }
            }
            
        }else if(input.equals("n")){
            System.out.println("돌아갑니다.");
        }
       
    }
    
    public void SnackBar(){
      //팝콘
      PopcornChef popcornChef = new PopcornChef();
      PopcornOrder popcornOrder = new PopcornOrder(popcornChef);
      
      //주스
      DrinkChef drinkChef = new DrinkChef();
      DrinkOrder drinkOrder = new DrinkOrder(drinkChef);
      
      //버거
      BurgerChef burgerChef = new BurgerChef();
      BurgerOrder burgerOrder = new BurgerOrder(burgerChef);
      
      //핫도그 
      HotdogChef hotdogChef = new HotdogChef();
      HotdogOrder hotdogOrder = new HotdogOrder(hotdogChef);
      
      //나쵸 
      NachoChef nachoChef = new NachoChef();
      NachoOrder nachoOrder = new NachoOrder(nachoChef);
      
      //세트
      SetChef setChef = new SetChef();
      SetOrder setOrder = new SetOrder(setChef);

      Scanner scan =new Scanner(System.in);
      int a = 0;
      while(true) {
            System.out.println("원하는 주문목록의 번호를 입력해주세요.\n0  매점 나가기"
                    + "\n1  팝콘메뉴\n2  주스메뉴\n3  버거메뉴\n4  핫도그메뉴"
                    + "\n5  나쵸메뉴\n6  세트메뉴\n--------------");
            
          a = scan.nextInt();
          
          if(a==0) {
              System.out.println("매점을 나가겠습니다.");
              break;
          }
          else if(a==1) {
              Staff staff =new Staff(popcornOrder);
              staff.setCommand(popcornOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else if(a==2) {
              Staff staff =new Staff(drinkOrder);
              staff.setCommand(drinkOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else if(a==3) {
              Staff staff =new Staff(burgerOrder);
              staff.setCommand(burgerOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else if(a==4) {
              Staff staff =new Staff(hotdogOrder);
              staff.setCommand(hotdogOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else if(a==5) {
              Staff staff =new Staff(nachoOrder);
              staff.setCommand(nachoOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else if(a==6) {
              Staff staff =new Staff(setOrder);
              staff.setCommand(setOrder);
              staff.takeOrder();
              System.out.println("음식을 받았습니다.");
          }
          else System.out.println("잘못된 번호를 입력하셨습니다.");
      }
    }
    
    public void MovieInformaiton(){
        MovieList movieList = new MovieList();
        ReOpenMovieList reOpenMovieList = new ReOpenMovieList();
        MovieDisplay movieDisplay = new MovieDisplay(movieList, reOpenMovieList);
        Scanner scan = new Scanner(System.in);
        int choice;
        
        while(true){
            System.out.println("원하는 기능을 입력하세요(1: 최신 영화 목록, 2: 재개봉 영화 목록, 3: 종료)");
            choice = scan.nextInt();
            
            if(choice == 1){
                movieDisplay.printMovieList();
            }else if(choice == 2){
                movieDisplay.printReOpenMovieList();
            }else if(choice == 3){
                break;
            }else{
                System.out.println("잘못 입력하셨습니다.");
            }
        }
    }
    
}
