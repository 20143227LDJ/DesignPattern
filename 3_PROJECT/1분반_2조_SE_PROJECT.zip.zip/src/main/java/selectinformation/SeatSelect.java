
package selectinformation;

import java.util.Scanner;

/**
 *
 * @author smile
 */
public class SeatSelect {
    PersonNumberSelect pns = new PersonNumberSelect();
    int[] seat = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
    int n1;
    
    public SeatSelect(int n1){
        this.n1 = n1;
    }
    public void showSeatInformation(){
        System.out.println("--------좌석 선택--------");
        for(int i = 0; i<seat.length; i++){
            System.out.print(seat[i] + "\t");
            if(((i+1)%5)==0){
                System.out.println();
            }
        }
        System.out.println("----------------------------");
        
    }
    
    public int[] selectSeat(){
        Scanner scan = new Scanner(System.in);
        int[] num = new int[n1];
        int n;
        
        for(int i = 0; i<n1;i++){
            System.out.print("좌석 번호를 입력하세요> ");
            
            while(true){
                n = scan.nextInt();
                scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
                if((n >= 1)&&(n <= 20)){
                    num[i] = n;
                    break;
                }
                else {
                    System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
                }
            }
        }
        
        for(int i = 0; i<n1; i++){
            System.out.print(num[i]+" ");
        }
        System.out.println("를 선택하셨습니다.\n");
        
        return num;
    }
}
