
package selectinformation;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author smile
 */
public class TimeSelect {
    String[] timeArray;
    
    public void showTimeInformation(){        
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("8:00 ~ 10:00");
        arrayList.add("10:00 ~ 23:00");
        arrayList.add("23:00 ~ 1:00");
        
        timeArray = arrayList.toArray(new String[arrayList.size()]);

        System.out.println("--------영화 시간 선택--------");
        for(int i = 0; i<timeArray.length; i++){
            System.out.println( i+1 + ". " + timeArray[i]);
        }
        System.out.println("----------------------------");
    }
    
    public int selectTime(){
        Scanner scan = new Scanner(System.in);
        int num;
        
        System.out.print("영화 시간 정보 번호를 입력하세요> ");
             
        while(true){
            num = scan.nextInt();
            scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
            
            if((num >= 1)&&(num <= timeArray.length)){
                break;
            }
            else {
                System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
            }
        }

        System.out.println( timeArray[num-1] +"를 선택하셨습니다.\n");
        
        return num+1;
    }
}
