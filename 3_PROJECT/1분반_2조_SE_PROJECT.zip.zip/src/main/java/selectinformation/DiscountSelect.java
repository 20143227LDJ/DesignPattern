
package selectinformation;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author smile
 */
public class DiscountSelect {
    String[] discountArray;
    
    public void showDiscountInformation(){        
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("학생 할인");
        arrayList.add("카드 할인");
        arrayList.add("학생, 카드 할인");
        arrayList.add("할인 선택 안함");
        
        discountArray = arrayList.toArray(new String[arrayList.size()]);


        System.out.println("--------할인 선택--------");
        for(int i = 0; i<discountArray.length; i++){
            System.out.println( i+1 + ". " + discountArray[i]);
        }
        System.out.println("----------------------------");
        
    }
    
    public int selectDiscount(){
        Scanner scan = new Scanner(System.in);
        int num;
        
        System.out.print("할인정보 번호를 입력하세요> ");
             
        while(true){
            num = scan.nextInt();
            scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
            
            if((num >= 1)&&(num <= discountArray.length)){
                break;
            }
            else {
                System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
            }
        }

        System.out.println( discountArray[num-1] +"를 선택하셨습니다.");
        
        return num;
    }
}
