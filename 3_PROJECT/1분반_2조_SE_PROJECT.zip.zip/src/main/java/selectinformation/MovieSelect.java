
package selectinformation;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author smile
 */
public class MovieSelect {
    String[] movieArray;
    
    public void showMovieInformation(){        
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("기생충");
        arrayList.add("알라딘");
        arrayList.add("악인전");
        arrayList.add("고질라:킹 오브 몬스터");
        arrayList.add("스쿨 오브 락");
        arrayList.add("트루먼 쇼");
        arrayList.add("레옹");
        
        movieArray = arrayList.toArray(new String[arrayList.size()]);


        System.out.println("--------영화 선택--------");
        for(int i = 0; i<movieArray.length; i++){
            System.out.println( i+1 + ". " + movieArray[i]);
        }
        System.out.println("----------------------------");
        
    }
    
    public String selectMovie(){
        Scanner scan = new Scanner(System.in);
        int num;
        
        System.out.print("보실 영화 번호를 입력하세요> ");
             
        while(true){
            num = scan.nextInt();
            scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
            
            if((num >= 1)&&(num <= movieArray.length)){
                break;
            }
            else {
                System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
            }
        }

        System.out.println( movieArray[num-1] +"를 선택하셨습니다.\n");
        
        return movieArray[num-1];
    }
}
