
package selectinformation;

import java.util.Scanner;

/**
 *
 * @author smile
 */
public class PersonNumberSelect {
    private int pNum;
    
    public int selectPersonNumber(){
        Scanner scan = new Scanner(System.in);
        
        System.out.println("--------인원 수 선택--------");
        System.out.print("1명부터 20명까지 인원 수를 적어주세요> ");
             
        while(true){
            pNum = scan.nextInt();
            scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
            
            if((pNum >= 1)&&(pNum <= 20)){
                break;
            }
            else {
                System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
            }
        }

        System.out.println( pNum +"명을 선택하셨습니다.\n");
        
        return pNum;
    }
    
    public int getPnum(){
        return pNum;
    }
}
