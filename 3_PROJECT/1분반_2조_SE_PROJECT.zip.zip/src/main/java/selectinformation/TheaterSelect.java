
package selectinformation;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author smile
 */
public class TheaterSelect {
    String[] theaterArray;
    
    public void showTheaterInformation(){        
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("동의시네마");
        arrayList.add("CGV");
        arrayList.add("메가박스");
        arrayList.add("롯데시네마");
        
        theaterArray = arrayList.toArray(new String[arrayList.size()]);


        System.out.println("--------영화관 선택--------");
        for(int i = 0; i<theaterArray.length; i++){
            System.out.println( i+1 + ". " + theaterArray[i]);
        }
        System.out.println("----------------------------");
        
    }
    
    public String selectTheater(){
        Scanner scan = new Scanner(System.in);
        int num;
        
        System.out.print("영화관 번호를 입력하세요> ");
             
        while(true){
            num = scan.nextInt();
            scan.nextLine(); //개행문자(엔터)를 제거하기위해 추가
            
            if((num >= 1)&&(num <= theaterArray.length)){
                break;
            }
            else {
                System.out.print("잘못입력하셨습니다. 다시 입력해주세요.> ");
            }
        }

        System.out.println( theaterArray[num-1] +"를 선택하셨습니다.\n");
        
        return theaterArray[num-1];
    }
}
