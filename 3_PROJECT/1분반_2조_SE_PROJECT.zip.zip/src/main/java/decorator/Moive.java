/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

/**
 *
 * @author smile
 */
public class Moive extends Ticket {
    
    public Moive(){
        description = "10:00 ~ 23:00";
    }
    
    public int price(){
        return 9000;
    }
}
