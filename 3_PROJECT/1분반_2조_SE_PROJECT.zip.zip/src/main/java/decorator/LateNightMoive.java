/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

/**
 *
 * @author smile
 */
public class LateNightMoive extends Ticket {
    
    public LateNightMoive(){
        description = "23:00 ~ 1:00";
    }
    
    public int price(){
        return 8000;
    }
}
