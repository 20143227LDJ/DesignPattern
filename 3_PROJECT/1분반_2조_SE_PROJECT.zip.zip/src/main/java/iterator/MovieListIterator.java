
package iterator;

import java.util.ArrayList;
import java.util.List;

public class MovieListIterator implements Iterator {
  List movieItems = new ArrayList();
  private int index = 0;

  public MovieListIterator(List movieItems) {
      this.movieItems = movieItems;
  }

  public boolean hasNext() {
      return (index < movieItems.size() && movieItems.get(index) != null);
  }

  public Object next() {
      Object movieItem = movieItems.get(index);
      index++;
      return movieItem;
  }

}
