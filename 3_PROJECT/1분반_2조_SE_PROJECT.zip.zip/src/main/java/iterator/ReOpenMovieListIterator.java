
package iterator;

class ReOpenMovieListIterator implements Iterator {
    MovieItem[] movieItems;
  private int index;

  public ReOpenMovieListIterator(MovieItem[] movieItems) {
      this.movieItems = movieItems;
  }

  public boolean hasNext() {
      return (index < movieItems.length && movieItems[index] != null);
  }

  public Object next() {
      MovieItem movieItem = movieItems[index];
      index++;
      return movieItem;
  }

}
