
package iterator;

public class ReOpenMovieList implements Movie {
  private static final int MAX = 3;
  private int index = 0;
  private MovieItem[] movieItems;
  
  public ReOpenMovieList() {
      movieItems = new MovieItem[MAX];
      
      add("코미디", "스쿨 오브 락", "109분", "2004.02.27");
      add("코미디, 드라마, SF", "트루먼 쇼", "103분", "1998.10.24");
      add("범죄, 액션, 드라마", "레옹", "132분", "1995.02.18");
  }

  public void add(String genre, String name, String time, String releaseDate) {
      MovieItem movieItem = new MovieItem(genre, name, time, releaseDate);
      
      if(index < MAX){
          movieItems[index] = movieItem;
          index++;
      }else{
          System.err.println("MAX 초과");
      }
  }

  

  public Iterator iterator() {
      return new ReOpenMovieListIterator(movieItems);
  }

}
