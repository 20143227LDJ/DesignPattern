
package iterator;

class MovieItem {
  private String genre;
  private String name;
  private String time;
  private String releaseDate;
  
  public MovieItem(String genre, String name, String time, String releaseDate) {
      this.genre = genre;
      this.name = name;
      this.time = time;
      this.releaseDate = releaseDate;
  }
  

  public String getGenre() {
      return genre;
  }

  public String getName() {
      return name;
  }

  public String getTime() {
      return time;
  }

  public String getReleaseDate() {
      return releaseDate;
  }

}
