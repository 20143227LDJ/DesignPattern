
package iterator;

import java.util.ArrayList;

public class MovieList implements Movie {
  private ArrayList movieItems;
  
  public MovieList() {
      movieItems = new ArrayList();
      
      add("드라마", "기생충", "131분", "2019.05.30");
      add("모험, 가족, 판타지, 멜로/로맨스", "알라딘", "128분", "2019.05.23");
      add("범죄, 액션", "악인전", "110분", "2019.05.15");
      add("액션, 모험", "고질라:킹 오브 몬스터", "132분", "2019.05.29");
  }

  public void add(String genre, String name, String time, String releaseDate) {
      MovieItem movieItem = new MovieItem(genre, name, time, releaseDate);
      movieItems.add(movieItem);
  }

  public Iterator iterator() {
      return new MovieListIterator(movieItems);
  }

}
