
package iterator;

interface Movie {
  Iterator iterator() ;

}
