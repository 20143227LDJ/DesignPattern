
package iterator;

public class MovieDisplay {
  private Movie movieList = new MovieList();
  private Movie reOpenMovieList = new ReOpenMovieList();

  public MovieDisplay(MovieList movieList, ReOpenMovieList reOpenMovieList){
      this.movieList = movieList;
      this.reOpenMovieList = reOpenMovieList;
  }
  
  public void printMovieList() {
      Iterator movieListIterator = movieList.iterator();
      
      System.out.println("----최신 영화----");
      printMovieList(movieListIterator);

  }
  
  public void printReOpenMovieList() {
      Iterator reOpenMovieListIterator = reOpenMovieList.iterator();
      
      System.out.println("----재개봉 영화----");
      printMovieList(reOpenMovieListIterator);
  }
  
  private void printMovieList(Iterator iterator){
      while(iterator.hasNext()){
          MovieItem movieItem = (MovieItem)iterator.next();
          System.out.println("장르 : " + movieItem.getGenre());
          System.out.println("이름 : " + movieItem.getName());
          System.out.println("상영 시간 : " + movieItem.getTime());
          System.out.println("개봉 날짜 : " + movieItem.getReleaseDate());
          System.out.println("---------------");
          
      }
          
  }

}
