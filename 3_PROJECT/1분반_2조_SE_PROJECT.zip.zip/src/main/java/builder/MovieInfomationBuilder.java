/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package builder;

/**
 *
 * @author user
 */
public class MovieInfomationBuilder {
    private String name;
    private int time;
    private int discount;
    private String theater;
    private int[] seat;
    private int personNum;

    public MovieInfomationBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public MovieInfomationBuilder setTime(int time) {
        this.time = time;
        return this;
    }

    public MovieInfomationBuilder setDiscount(int discount) {
        this.discount = discount;
        return this;
    }

    public MovieInfomationBuilder setTheater(String theater) {
        this.theater = theater;
        return this;
    }
    
    public MovieInfomationBuilder setSeat(int[] seat) {
        this.seat = seat;
        return this;
    }
    
    public MovieInfomationBuilder setPersonNumber(int personNum) {
        this.personNum = personNum;
        return this;
    }

    public MovieInformation build(){
        return new MovieInformation(name,time, discount, theater, seat, personNum);
    }
}

