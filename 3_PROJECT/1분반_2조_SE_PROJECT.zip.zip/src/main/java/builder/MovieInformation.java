/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package builder;

/**
 *
 * @author user
 */
public class MovieInformation {
    /**
 * 제약사항 : 이 객체는 한번 생성되면 읽기(Read)만 가능해야 합니다.
 */
    private String name;
    private int time;
    private int discount;
    private String theater;
    private int[] seat;
    private int personNum;

    public MovieInformation(String name, int time, int discount, String theater, int[] seat, int personNum){
        this.name = name;
        this.time = time;
        this.discount = discount;
        this.theater = theater;
        this.seat = seat;
        this.personNum = personNum;
    }

    public String getName() {
        return name;
    }

    public int getTime() {
        return time;
    }

    public int getDiscount() {
        return discount;
    }

    public String getTheater() {
        return theater;
    }
    
    public int[] getSeat() {
        return seat;
    }
    
    public int getPersonNumber() {
        return personNum;
    }

    public String getMovieInfo(){
        return String.format("영화관:%s, 영화이름:%s, 영화시간:%d, 결제정보:%d, 사람수:%d "
               ,theater , name, time, discount, personNum);
    }
}